# PulseGuard AI Frontend

## Installation

```bash
npm install
npm run dev
```

Open:
http://localhost:5173
